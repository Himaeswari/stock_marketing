package com.stock.stockexchange.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.AdminDao;
import com.stock.stockexchange.model.User;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	AdminDao adminDao;
	
	@Override
	public User validateUser(int user, String password) throws SQLException
	{
		
		
	  User check=adminDao.validateUser(user,password);
	  System.out.println("hi "+check);
	  return check;
	}
	
}

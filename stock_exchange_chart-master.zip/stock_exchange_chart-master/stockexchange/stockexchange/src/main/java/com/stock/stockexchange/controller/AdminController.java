package com.stock.stockexchange.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.User;
import com.stock.stockexchange.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@RequestMapping(value = "/adminLogin", method = RequestMethod.GET)

	public ModelAndView home(HttpServletRequest request,Model model)
	{
		 model.addAttribute("login", new User());
		return new ModelAndView("admin-login");
	}

	
	
	@RequestMapping(value = "/adminLoginProcess", method = RequestMethod.POST)

	public String login(@RequestParam("userId") String userName, @RequestParam("password") String password,
			ModelMap map, HttpServletRequest request)
	{
		User users = new User();
		
		Boolean check = false;
		
		
			int user = Integer.parseInt(userName);
		
			try
			{
				users= adminService.validateUser(user, password);
			} 
			catch (SQLException e)
			{
				System.out.println(e);
			}

			if (users!=null)
			{
				
				
				return "admin-landing-page";

			}

			else if(users==null)
			{
				
				return "redirect:/adminLogin";
			} 
			
		return "redirect:/adminLogin";

	}
}

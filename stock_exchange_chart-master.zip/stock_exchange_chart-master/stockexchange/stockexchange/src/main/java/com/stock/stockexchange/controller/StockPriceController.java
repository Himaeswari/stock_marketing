package com.stock.stockexchange.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.dao.StockPriceDao;
import com.stock.stockexchange.model.StockPrice;
import com.stock.stockexchange.service.StockPriceService;


@RequestMapping("/api")
@RestController
public class StockPriceController {

	
	@Autowired
    StockPriceService stockPriceService;
	@GetMapping("/stockPrice/{id}")
	public float getAllCustomers(@PathVariable("id") int id) {
		System.out.println("Get all company by sector...");

		
		float stockPrice=stockPriceService.findStockPrice(id);

		return stockPrice;
	}
	

@GetMapping("/stockPriceDetail/{companyCode}/{startdate}/{enddate}")
     public List<StockPrice> getStockPriceDetail(@PathVariable("companyCode") int companyCode,
                @PathVariable("startdate") Date startdate, @PathVariable("enddate") Date enddate) {
           return stockPriceService.findBydate(companyCode, startdate, enddate);
     }

}

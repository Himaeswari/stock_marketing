package com.stock.stockexchange.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.User;
import com.stock.stockexchange.service.LoginService;

@Controller
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)

	public ModelAndView home(HttpServletRequest request,Model model)
	{
		 model.addAttribute("login", new User());
		return new ModelAndView("admin-login");
	}

	
	
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)

	public String login(@RequestParam("userId") String userName, @RequestParam("password") String password,
			ModelMap map, HttpServletRequest request)
	{
		User users = new User();
		
		Boolean check = false;
		
		
			int user = Integer.parseInt(userName);
		
			try
			{
				users= loginService.validateUser(user, password);
			} 
			catch (SQLException e)
			{
				System.out.println(e);
			}

			if (users!=null)
			{
				
				
				return "admin-landing-page";

			}

			else if(users==null)
			{
				
				return "redirect:/login";
			} 
			
		return "redirect:/login";

	}
	

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String getUserForm(ModelMap model) {
		System.out.println("add user");
		User user = new User();
		
		model.addAttribute("user", user);
		return "registration";
		
		

		
	}
	
	@RequestMapping(value = "/addUserProcess", method = RequestMethod.POST)
	public String formHandler(@Valid @ModelAttribute("user") User user,BindingResult result,
			 Model model) throws SQLException {
		
		
		
		System.out.println(user);
		
		if(result.hasErrors()){
			System.out.println("eror");
				model.addAttribute("user",user);
				return "registration";
			}
		
		loginService.insertUser(user);
	
		 return "redirect:/login";
	}
}

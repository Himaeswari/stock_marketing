package com.stock.stockexchange.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.StockPriceDao;
import com.stock.stockexchange.model.StockPrice;

@Service
public class StockPriceServiceImpl implements StockPriceService{

	@Autowired
	StockPriceDao stockPriceDao;
	
	@Override
	public List<StockPrice> findBydate(int companyCode, Date startdate, Date enddate) {
		
		return stockPriceDao.findBydate(companyCode, startdate, enddate);
	}

	@Override
	public float findStockPrice(int id) {
		
		return stockPriceDao.findStockPrice(id);
	}

}

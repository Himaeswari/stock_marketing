package com.stock.stockexchange.service;

import java.sql.SQLException;

import com.stock.stockexchange.model.User;

public interface AdminService {
	public User validateUser(int user, String password) throws SQLException;
}

package com.stock.stockexchange.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.dao.SectorDao;
import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.StockPrice;
import com.stock.stockexchange.service.CompanyService;
import com.stock.stockexchange.service.SectorService;


@RequestMapping("/api")
@RestController
public class CompanyController {
@Autowired
	SectorService sectorService;
	
	@Autowired
	CompanyService companyService;
	
	
	@GetMapping("/getCompanyBySector/{id}")
	public List<Company> getCompanyBySector(@PathVariable("id") int id) {
		System.out.println("Get all company by sector...");

		List<Company> company = new ArrayList<>();
		company=companyService.findCompanyBySector(id);

		return company;
	}

	@GetMapping("/getMatchingCompany/{name}")
	public List<Company> getMatchingCompany(@PathVariable("name") String name) {
		System.out.println("Get all company by sector...");

		List<Company> company = new ArrayList<>();
		company=companyService.findMatchingCompany(name);

		return company;
	}
	
	@GetMapping("/upload")
    public List<StockPrice> upload() throws IOException, ParseException {
         

           List<StockPrice> stockpricedata = new ArrayList<>();
           StockPrice Object1 =null;
           FileInputStream file = new FileInputStream(new File("C:\\Users\\761156\\Downloads\\Book1.xlsx")); 
           @SuppressWarnings("resource")
           XSSFWorkbook workbook = new XSSFWorkbook(file); 
           XSSFSheet sheet = workbook.getSheetAt(0); 
     Row row;
     for(int i=1; i<=sheet.getLastRowNum(); i++){  //points to the starting of excel i.e excel first row
         row = (Row) sheet.getRow(i);  //sheet number
         
         
                String idS;
                        if( row.getCell(0)==null) { idS = "0"; }
                else idS= row.getCell(0).toString();
                        
                        float id1 = Float.parseFloat(idS),companyid1,stockexchangeid1;
                        
                        
                        
                        String companyidS;
                        if( row.getCell(1)==null) { companyidS = "0"; }
                else companyidS= row.getCell(1).toString();

                        companyid1= Float.parseFloat(companyidS);
                        
                        
                        String stockexchangeidS;
                        if( row.getCell(2)==null) { stockexchangeidS = "0"; }
                else stockexchangeidS= row.getCell(2).toString();
                        
                        stockexchangeid1= Float.parseFloat(stockexchangeidS);
                        
                        int id=(int)id1,companyid=(int)companyid1,stockexchangeid=(int)stockexchangeid1;
                        
                String currentPriceS;
                        if( row.getCell(3)==null) { currentPriceS = "0";}  //suppose excel cell is empty then its set to 0 the variable
                else currentPriceS = row.getCell(3).toString();   //else copies cell data to name variable

                        float currentPrice = Float.parseFloat(currentPriceS);
                        
                         
                         
                String dateinexcelS;
                        if( row.getCell(4)==null) { dateinexcelS = "null";   }
                else  dateinexcelS   = row.getCell(4).toString();
                        
                           
                            Date dateinexcel=new SimpleDateFormat("dd/MM/yyyy").parse(dateinexcelS); 
                        
                            
                            
                         String timeinexcelS;
                               if( row.getCell(5)==null) { timeinexcelS = "null";   }
                       else  timeinexcelS   = row.getCell(5).toString();
                               
                               
                               DateFormat sdf = new SimpleDateFormat("hh:mm:ss");
                               Date timeinexcel = sdf.parse(timeinexcelS);
    
       System.out.println("Id :"+id+"companyid :"+companyid+"     stockexchangeid :"+stockexchangeid+
                                "    currentPrice :"+currentPrice+"    dateinexcel :"+dateinexcel+
                                "    timeinexcel :"+timeinexcel);
        Object1 = new StockPrice(id,companyid,stockexchangeid,currentPrice,dateinexcel,timeinexcel);
       
           stockpricedata.add(Object1);
           Object1 = null;
     }
           file.close();
           //stockpriceservice.findAll().forEach(stockpricedata::add);

           return stockpricedata;
    }

	
}


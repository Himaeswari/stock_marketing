package com.stock.stockexchange.service;

import java.util.Date;
import java.util.List;

import com.stock.stockexchange.model.StockPrice;

public interface StockPriceService {

	List<StockPrice> findBydate(int companyCode, Date startdate, Date enddate);

	float findStockPrice(int id);

}
